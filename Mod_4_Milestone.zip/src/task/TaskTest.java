/**********************
 * Module 4 Milestone *
 * by Justin Leger    *
 * January 30th 2025  *
 **********************/

package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTaskConstructor() {
		Task task = new Task("123456789", "John", "Doe");
		assertTrue(task.getId().equals("123456789"));
		assertTrue(task.getName().equals("John"));
		assertTrue(task.getDescription().equals("Doe"));
	}
	
	@Test
	void testTaskSetters() {
		Task task = new Task();
		task.setId("987654321");
		task.setName("Patrick");
		task.setDescription("Fitzpatrik");
		assertTrue(task.getId().equals("987654321"));
		assertTrue(task.getName().equals("Patrick"));
		assertTrue(task.getDescription().equals("Fitzpatrik"));
	}
	
	@Test
	void testTaskIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, null, null);
		});
	}
}
