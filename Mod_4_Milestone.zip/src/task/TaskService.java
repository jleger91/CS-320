/**********************
 * Module 4 Milestone *
 * by Justin Leger    *
 * January 30th 2025  *
 **********************/

package task;
import java.util.ArrayList;
import java.util.Random;

public class TaskService{
	ArrayList<Task> tasks = new ArrayList<Task>(); //Create an ArrayList
	
	String createUniqueId() {
		Random rand = new Random();
		long randomNumber = (long) (rand.nextDouble() * 1_000_000_0000L);
		String uniqueId = String.valueOf(randomNumber);
		return uniqueId;
	}
	
	/**************
	 * add object *
	 **************/
	void addTask(String id, String name, String description) {
		Task task = new Task(id, name, description);
		tasks.add(task); //add contact to list
	}
	void addTask(Task task) {
		tasks.add(task); //add contact to list
	}
	//end add object
	
	
	//remove object
	void removeTask(String id) {
		tasks.removeIf(e -> e.getId().equals(id));	
	}
	
	//edit object
	void editTask(String id, String name, String desc) {
		//for all of the tasks
		for (int i=0; i < tasks.size(); i++) {
			//see if the current tasks matches
			if (tasks.get(i).getId().equals(id)) {
				tasks.get(i).setName(name);
				tasks.get(i).setDescription(desc);
			}
		}
	}
}
