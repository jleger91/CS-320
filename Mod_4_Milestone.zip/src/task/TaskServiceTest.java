/**********************
 * Module 4 Milestone *
 * by Justin Leger    *
 * January 30th 2025  *
 **********************/

package task;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testAddTask() {
		TaskService serv = new TaskService();
		String uniqueId = serv.createUniqueId();
		Task task = new Task(uniqueId, "Jerry", "James");
		serv.addTask(task);
		
		assertTrue(serv.tasks.getFirst().getId().equals(uniqueId));
		assertTrue(serv.tasks.getFirst().getName().equals("Jerry"));
		assertTrue(serv.tasks.getFirst().getDescription().equals("James"));
	}
	
	@Test
	void testRemoveTask() {
		TaskService serv = new TaskService();
		String uniqueId = serv.createUniqueId();
		Task task = new Task(uniqueId, "Jerry", "James");
		serv.addTask(task);
		serv.removeTask(uniqueId);

		ArrayList<Task> emptyTasks = new ArrayList<Task>();
		assertEquals(serv.tasks, emptyTasks, "The tasks is still there");
	}
	
	@Test 
	void testEditTask(){
		TaskService serv = new TaskService();
		String uniqueId = serv.createUniqueId();
		Task task = new Task(uniqueId, "Jerry", "James");
		serv.addTask(task);
		serv.editTask(uniqueId, "Lebron", "James");
		
		assertTrue(serv.tasks.getFirst().getId().equals(uniqueId));
		assertTrue(serv.tasks.getFirst().getName().equals("Lebron"));
		assertTrue(serv.tasks.getFirst().getDescription().equals("James"));
	}

}
