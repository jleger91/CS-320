/**********************
 * Module 4 Milestone *
 * by Justin Leger    *
 * January 30th 2025  *
 **********************/

package task;

public class Task{
	
	private String id;
	private String name;
	private String description;
	
	/**********************
	 *  BEGIN CONSTRUCTOR *
	 **********************/
	public Task() {}
	
	public Task(String id, String name, String description) {
		
		if(id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(name == null || name.length()>20) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if(description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		this.id = id;
		this.name = name;
		this.description = description;
	}
	
	/*************************
	 *  BEGIN GETTER METHODS *
	 *************************/
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	
	/*************************
	 *  BEGIN SETTER METHODS *
	 *************************/
	public void setId(String id) {
		if(id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		this.id = id;
	}
	public void setName(String name) {
		if(name == null || name.length()>30) {
			throw new IllegalArgumentException("Invalid ID");
		}
		this.name = name;
	}
	public void setDescription(String description) {
		if(description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
}